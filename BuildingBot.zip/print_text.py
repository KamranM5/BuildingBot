from config import *
print("""CREATE TABLE IF NOT EXISTS """ + table_name + """(
    id INTEGER NOT NULL PRIMARY KEY,
    fio TEXT,
    user_name text,
    user_surname text,
    username text,
    comment text,
    photo BLOB,
    """ + data1 + """ text,
    """ + data2 + """ text,
    """ + data3 + """ text,
    """ + data4 + """ text)""")