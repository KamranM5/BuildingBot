import sqlite3
def myf(path):
  f = open(path, 'rb')
  obj = f.read()
  return obj

#creat first DataBase

db1 = sqlite3.connect('users.sqlite')
sql1 = db1.cursor()
data1 = """CREATE TABLE IF NOT EXISTS users1(id INT,comment TEXT,data BLOB)"""
sql1.execute(data1)

id = str(1)
comment = 'first comment'

my_photo = myf('C://Users//user//Desktop//Uni_Project//oxy.jpg')
sql1.execute('INSERT INTO users1 VALUES (?, ?, ?)', (id, comment, my_photo))
db1.commit()
sql1.close()
db1.close()

#creat second DataBase

db2 = sqlite3.connect(r'C://Users//user//Desktop//TEST2//users2.sqlite')
sql2 = db2.cursor()

data2 = """CREATE TABLE IF NOT EXISTS users2(id INT,data BLOB, comment TEXT)"""

sql2.execute(data2)

comment2 = 'second comment'

my_photo2 = myf('C://Users//user//Desktop//Uni_Project//nlo.jpg')

sql2.execute('INSERT INTO users2 VALUES (?, ?, ?)', (id,comment2, my_photo2))

db2.commit()
sql2.close()
db2.close()

#creat 3th DataBase

db3 = sqlite3.connect(r'C://Users//user//Desktop//TEST3//users3.sqlite')
sql3 = db3.cursor()

data3 = """CREATE TABLE IF NOT EXISTS users3(id INT,data BLOB, comment TEXT)"""

sql3.execute(data3)


id3 = str(3)
comment3 = '3th comment'
my_photo3 = myf('C://Users//user//Desktop//Uni_Project//bmw.jpg')

sql3.execute('INSERT INTO users3 VALUES (?, ?, ?)', (id, comment3, my_photo3))

db3.commit()
sql3.close()
db3.close()