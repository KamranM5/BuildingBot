token = '5639367393:AAG8ViAIb6zHY1o0reIAcdpb4183LWe_ZUI'

geo_latitude = 47.208105
geo_longtude = 39.588218

db_name = 'database'

table_name = 'users'

# наличие трещин

data1 = 'Трещины'

command1 = 'crack'
command1_del = command1 + '_del'

button_name1 = 'Наличие трещин'
button_name1_del = 'Удалить пункт: ' + button_name1

# наличие деформаций

data2 = 'Деформации'

command2 = 'deformatian'
command2_del = command2 + '_del'

button_name2 = 'Наличие деформаций'
button_name2_del = 'Удалить пункт: ' + button_name2

# наличие пространственных отклонений

data3 = 'Пространственные_отклонения'

command3 ='spatial_deviations'
command3_del = command3 + '_del'

button_name3 = 'Наличие пространственных отклонений'
button_name3_del = 'Удалить пункт: ' + button_name3

# сквозные отверстия в основании колонны

data4 = 'Сквозные_отверстия_в_основании_колонныы'

command4 = 'through_holes_in_the_base_of_the_columnhole'
command4_del = command4 + '_del'

button_name4 = 'Сквозные отверстия в основании колонны'
button_name4_del = 'Удалить пункт: ' + button_name4

# геопозиция

geo_data = 'Геопозиция'
command5 = 'geoposition'
