import sqlite3
def myf(path):
  f = open(path, 'rb')
  obj = f.read()
  return obj

#creat first DataBase

db1 = sqlite3.connect('users1.sqlite')
sql1 = db1.cursor()
data = """CREATE TABLE IF NOT EXISTS users(id INT,comment TEXT,data BLOB)"""
sql1.execute(data)

id = str(1)
comment = 'first comment'

my_photo = myf('C://Users//user//Desktop//Uni_Project//bmw.jpg')
sql1.execute('INSERT INTO users VALUES (?, ?, ?)', (id, comment, my_photo))
db1.commit()
sql1.close()
db1.close()

#creat second DataBase

db2 = sqlite3.connect(r'C://Users//user//Desktop//TEST2//users2.sqlite')
sql2 = db2.cursor()
sql2.execute(data)


sql2.execute('INSERT INTO users VALUES (?, ?, ?)', (id, comment, my_photo))

db2.commit()
sql2.close()
db2.close()

#creat 3th DataBase

db3 = sqlite3.connect(r'C://Users//user//Desktop//TEST3//users3.sqlite')
sql3 = db3.cursor()
sql3.execute(data)

sql3.execute('INSERT INTO users VALUES (?, ?, ?)', (id, comment, my_photo))

db3.commit()
sql3.close()
db3.close()