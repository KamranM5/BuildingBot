import telebot
from telebot import types
import time
import os
import sqlite3
from functions import *
from config import *

bot = telebot.TeleBot(token)

data = """CREATE TABLE IF NOT EXISTS """ + table_name + """(
    id INTEGER NOT NULL PRIMARY KEY,
    telegram_id INTEGER,
    fio TEXT,
    user_name text,
    user_surname text,
    username text,
    comment text,
    photo BLOB,
    """ + data1 + """ text,
    """ + data2 + """ text,
    """ + data3 + """ text,
    """ + data4 + """ text)"""
cursor.execute(data)

def nextStepHandler(message):
    def nextStepHandlerImplementation(func):
        def onMessage(message):
            if message.content_type == 'text' and message.text in commands.values():
                bot.clear_step_handler_by_chat_id(chat_id=message.chat.id)
                textMessageHandler(message)
                return
            if func(message):
                bot.register_next_step_handler(message, onMessage)
        bot.register_next_step_handler(message, onMessage)
    return nextStepHandlerImplementation

def createPathIfNotExists(path):
    if not os.path.exists(path):
        os.makedirs(path)
def botPolling():
    while True:
        try:
            print('starting bot...')
            bot.polling(none_stop=True, interval=0.1)
        except Exception as ex:
            print('bot error... restarting...', ex)
            bot.stop_polling()
            time.sleep(0.1)

# cteat commands list

if __name__ == '__main__':
    bot = telebot.TeleBot(token)
    commands = {
        'fio': 'Ввести ФИО',
        'comment': 'Отправить комментарий',
        'delete comment': 'Удалить комментарий',
        'photo': 'Отправить фото',
        'delete photo': 'Удалить фото',
        command1 : button_name1,
        command2 : button_name2,
        command3 : button_name3,
        command4 : button_name4,
        'delete all': 'Удалить всё',
    }
    def test(message):
        bot.send_message(message.chat.id,'You send me message')

    @bot.message_handler(commands=['start'])
    def welcome(message):
      mesg = bot.send_message(message.chat.id,'Please send me message')
      bot.register_next_step_handler(mesg,test)
        
    
    botPolling()