token = '5639367393:AAG8ViAIb6zHY1o0reIAcdpb4183LWe_ZUI'

geo_latitude = 47.208105
geo_longtude = 39.588218

db_name = 'bot'

host="127.0.0.1"
username="bot"
password="MySqlServer2022"
database="bot"

table_name = 'users222'

# наличие трещин

data1 = 'crack'
command1 = 'crack'

button_name1 = 'Наличие трещин'


# наличие деформаций

data2 = 'deformatian'
command2 = 'deformatian'

button_name2 = 'Наличие деформаций'


# наличие пространственных отклонений

data3 = 'spatial_deviations'
command3 ='spatial_deviations'

button_name3 = 'Наличие пространственных отклонений'

# сквозные отверстия в основании колонны

data4 = 'through_holes_in_the_base_of_the_columnhole'
command4 = 'through_holes_in_the_base_of_the_columnhole'

button_name4 = 'Сквозные отверстия в основании колонны'

# геопозиция

geo_data = 'Геопозиция'
command5 = 'geoposition'
