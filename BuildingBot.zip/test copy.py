from telebot import types
import time
import telebot
import os
import sqlite3
from functions import *
from config import *

bot = telebot.TeleBot(token)

data = """CREATE TABLE IF NOT EXISTS users(
    id INTEGER NOT NULL PRIMARY KEY,
    geo text)"""

cursor.execute(data)


def botPolling():
    while True:
        try:
            print('starting bot...')
            bot.polling(none_stop=True, interval=0.1)
        except Exception as ex:
            print('bot error... restarting...', ex)
            bot.stop_polling()
            time.sleep(0.1)


if __name__ == '__main__':
    bot = telebot.TeleBot(token)
    commands = {
        'fio': 'Ввести ФИО',
        'comment': 'Отправить комментарий',
        'delete comment': 'Удалить комментарий',
        'photo': 'Отправить фото',
        'delete photo': 'Удалить фото',
        command1 : button_name1,
        command2 : button_name2,
        command3 : button_name3,
        command4 : button_name4,
        'delete all': 'Удалить всё',
    }

if __name__ == '__main__':
    bot = telebot.TeleBot(token)
    
    @bot.message_handler(content_types=['location'])
    def bla(message):
        if message.location is not None:
            a = str(message.location.latitude)
            b = str(message.location.longitude)
            geo = f'{a} {b}'
        cursor.execute('update ' + table_name + ' set ' + command5 + ' = ? where telegram_id = ?', (geo, message.from_user.id))
        conn.commit()